import java.util.Scanner;

public class Drill1 {
    public static void main(String[] args) {
        int cash;
        Scanner sc = new Scanner(System.in);
        System.out.print("월급을 입력해주세요: ");
        cash = sc.nextInt();
        int tot;

        tot = cash * 120;

        System.out.println("10년 동안의 저축액: "+tot);
    }

}
